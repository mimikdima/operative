export interface IColor {
  id: number;
  name: string;
  color: string;
}
